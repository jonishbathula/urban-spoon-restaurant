import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import {
  createInquiry,
  listInquiries,
  getInquiry,
  deleteInquiry
} from '../controllers/inquiryController.js';

const router = Router();

const inquiryLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many inquiry requests. Please try again later.'
  }
});

router.get('/', listInquiries);
router.get('/:id', getInquiry);
router.post('/', inquiryLimiter, createInquiry);
router.delete('/:id', deleteInquiry);

export default router;
