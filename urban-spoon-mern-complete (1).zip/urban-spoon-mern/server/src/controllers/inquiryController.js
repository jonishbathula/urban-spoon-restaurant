import Inquiry from '../models/Inquiry.js';

function validateDate(dateString) {
  const selected = new Date(`${dateString}T00:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return !Number.isNaN(selected.getTime()) && selected >= today;
}

export async function createInquiry(req, res, next) {
  try {
    const { name, phone, email, date, time, guests, occasion, message } = req.body;

    if (!name || !phone || !date || !time || !guests) {
      return res.status(400).json({
        success: false,
        message: 'Name, phone, date, time and guest count are required.'
      });
    }

    if (!validateDate(date)) {
      return res.status(400).json({
        success: false,
        message: 'Please choose today or a future date.'
      });
    }

    const inquiry = await Inquiry.create({
      name,
      phone,
      email,
      date,
      time,
      guests,
      occasion,
      message
    });

    return res.status(201).json({
      success: true,
      message: 'Your table inquiry has been received.',
      data: {
        id: inquiry._id,
        name: inquiry.name,
        date: inquiry.date,
        time: inquiry.time,
        guests: inquiry.guests
      }
    });
  } catch (error) {
    next(error);
  }
}

export async function listInquiries(req, res, next) {
  try {
    const inquiries = await Inquiry.find().sort({ createdAt: -1 }).limit(200).lean();
    res.json({ success: true, count: inquiries.length, data: inquiries });
  } catch (error) {
    next(error);
  }
}

export async function getInquiry(req, res, next) {
  try {
    const inquiry = await Inquiry.findById(req.params.id).lean();
    if (!inquiry) return res.status(404).json({ success: false, message: 'Inquiry not found.' });
    res.json({ success: true, data: inquiry });
  } catch (error) {
    next(error);
  }
}

export async function deleteInquiry(req, res, next) {
  try {
    const deleted = await Inquiry.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ success: false, message: 'Inquiry not found.' });
    res.json({ success: true, message: 'Inquiry deleted.' });
  } catch (error) {
    next(error);
  }
}
