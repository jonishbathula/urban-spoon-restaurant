import ContactMessage from '../models/ContactMessage.js';

export async function createContactMessage(req, res, next) {
  try {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({
        success: false,
        message: 'Name, email and message are required.'
      });
    }

    const contact = await ContactMessage.create({ name, email, message });

    return res.status(201).json({
      success: true,
      message: 'Thanks! Your message has been received by Urban Spoon.',
      data: { id: contact._id }
    });
  } catch (error) {
    next(error);
  }
}
