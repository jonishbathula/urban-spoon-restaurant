export const categories = ['All', 'Starters', 'Main Course', 'Desserts', 'Beverages'];

export const menuItems = [
  {
    id: 1,
    name: 'Smoked Tomato Bruschetta',
    category: 'Starters',
    description: 'Charred sourdough, roasted tomato, basil oil and whipped feta.',
    price: 290,
    image: 'https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?auto=format&fit=crop&w=900&q=80',
    badge: 'Chef pick'
  },
  {
    id: 2,
    name: 'Crispy Truffle Fries',
    category: 'Starters',
    description: 'Golden fries finished with truffle oil, parmesan and herbs.',
    price: 260,
    image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=80',
    badge: 'Popular'
  },
  {
    id: 3,
    name: 'Urban Paneer Steak',
    category: 'Main Course',
    description: 'Tandoori paneer, charred vegetables, pepper sauce and greens.',
    price: 490,
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80',
    badge: 'Vegetarian'
  },
  {
    id: 4,
    name: 'Herb Grilled Chicken',
    category: 'Main Course',
    description: 'Juicy herb-marinated chicken with mash and seasonal vegetables.',
    price: 620,
    image: 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=900&q=80',
    badge: 'Signature'
  },
  {
    id: 5,
    name: 'Creamy Wild Mushroom Pasta',
    category: 'Main Course',
    description: 'Silky mushroom cream, parmesan, garlic and al dente pasta.',
    price: 520,
    image: 'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=80',
    badge: 'New'
  },
  {
    id: 6,
    name: 'Saffron Panna Cotta',
    category: 'Desserts',
    description: 'Silky saffron custard, pistachio crumb and berry compote.',
    price: 320,
    image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=900&q=80',
    badge: 'Sweet'
  },
  {
    id: 7,
    name: 'Dark Chocolate Tart',
    category: 'Desserts',
    description: '70% dark chocolate ganache, cocoa crust and sea salt.',
    price: 340,
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=80',
    badge: 'Best seller'
  },
  {
    id: 8,
    name: 'Citrus Basil Cooler',
    category: 'Beverages',
    description: 'Fresh citrus, basil, sparkling water and a touch of honey.',
    price: 210,
    image: 'https://images.unsplash.com/photo-1544145945-f90425340c7e?auto=format&fit=crop&w=900&q=80',
    badge: 'Refreshing'
  }
];
