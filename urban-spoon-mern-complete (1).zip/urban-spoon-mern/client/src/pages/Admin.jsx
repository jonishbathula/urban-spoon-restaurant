import { useEffect, useState } from 'react';
import { deleteInquiry, getInquiries } from '../services/api';
import { RefreshCcw, Trash2, ShieldAlert, LoaderCircle } from 'lucide-react';

export default function Admin() {
  const [records, setRecords] = useState([]);
  const [state, setState] = useState({ loading: true, error: '' });

  async function load() {
    setState({ loading: true, error: '' });
    try {
      const result = await getInquiries();
      setRecords(result.data || []);
      setState({ loading: false, error: '' });
    } catch (error) {
      setState({ loading: false, error: error.response?.data?.message || 'Could not load inquiries.' });
    }
  }

  useEffect(() => { load(); }, []);

  async function remove(id) {
    if (!window.confirm('Delete this inquiry?')) return;
    try {
      await deleteInquiry(id);
      setRecords(current => current.filter(item => item._id !== id));
    } catch (error) {
      window.alert(error.response?.data?.message || 'Delete failed.');
    }
  }

  return (
    <div className="page">
      <section className="admin-head">
        <div className="container admin-head-inner">
          <div>
            <span className="eyebrow light">Internal demo</span>
            <h1>Inquiry <span>dashboard.</span></h1>
          </div>
          <button className="btn btn-ghost" onClick={load}><RefreshCcw size={17} /> Refresh</button>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="admin-warning"><ShieldAlert size={18} /> Demo dashboard only — add authentication before production use.</div>
          {state.loading ? (
            <div className="state-card"><LoaderCircle className="spin" /> Loading inquiries...</div>
          ) : state.error ? (
            <div className="state-card error">{state.error}</div>
          ) : records.length === 0 ? (
            <div className="state-card">No table inquiries yet. Submit one from the Book a Table page.</div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>Name</th><th>Contact</th><th>Date</th><th>Time</th><th>Guests</th><th>Occasion</th><th>Action</th></tr>
                </thead>
                <tbody>
                  {records.map(item => (
                    <tr key={item._id}>
                      <td><strong>{item.name}</strong><small>{item.message || 'No note'}</small></td>
                      <td>{item.phone}<small>{item.email || 'No email'}</small></td>
                      <td>{item.date}</td>
                      <td>{item.time}</td>
                      <td>{item.guests}</td>
                      <td>{item.occasion}</td>
                      <td><button className="icon-btn danger" onClick={() => remove(item._id)} aria-label={`Delete ${item.name}`}><Trash2 size={17} /></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
