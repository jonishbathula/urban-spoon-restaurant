import { CalendarDays, Users, ShieldCheck } from 'lucide-react';
import InquiryForm from '../components/forms/InquiryForm';

export default function BookTable() {
  return (
    <div className="page">
      <section className="page-hero book-hero">
        <div className="container">
          <span className="eyebrow light">Table inquiry</span>
          <h1>Save a seat for <span>something delicious.</span></h1>
          <p>Send your preferred date and time. Our team can follow up to confirm availability.</p>
        </div>
      </section>

      <section className="section">
        <div className="container booking-grid">
          <div className="booking-intro">
            <span className="eyebrow">Make it yours</span>
            <h2>Tell us what you <span>need.</span></h2>
            <p>
              This demo sends your request through the Urban Spoon REST API and stores
              it in MongoDB. A real restaurant would connect the confirmation step to
              live table availability.
            </p>
            <div className="booking-points">
              <p><CalendarDays size={19} /><span><strong>Flexible timing</strong><br />Lunch and dinner reservations.</span></p>
              <p><Users size={19} /><span><strong>1–20 guests</strong><br />For larger groups, contact us directly.</span></p>
              <p><ShieldCheck size={19} /><span><strong>Your details stay private</strong><br />Only reservation information is stored.</span></p>
            </div>
          </div>
          <div className="form-panel">
            <InquiryForm />
          </div>
        </div>
      </section>
    </div>
  );
}
