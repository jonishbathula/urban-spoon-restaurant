import { Award, Users, UtensilsCrossed } from 'lucide-react';

const values = [
  { icon: UtensilsCrossed, title: 'Cook with intent', text: 'Every plate has a reason to be here: flavour, texture, comfort or surprise.' },
  { icon: Users, title: 'Serve people', text: 'Hospitality is not a script. We listen, adapt and make room for the moment.' },
  { icon: Award, title: 'Keep improving', text: 'We test, taste and refine so the experience gets better every season.' }
];

export default function About() {
  return (
    <div className="page">
      <section className="page-hero about-hero">
        <div className="container">
          <span className="eyebrow light">About Urban Spoon</span>
          <h1>A neighbourhood restaurant with a <span>city-sized appetite.</span></h1>
        </div>
      </section>

      <section className="section">
        <div className="container narrow-copy">
          <span className="eyebrow">The idea</span>
          <h2>Food should make people <span>stay longer.</span></h2>
          <p>
            Urban Spoon started with a simple thought: the best restaurants are not
            only about what arrives on the plate. They are about the people around
            the table, the music in the background and the stories that keep going
            after the last bite.
          </p>
          <p>
            We combine contemporary cooking with familiar Indian flavours, seasonal
            produce and a relaxed room. The result is food that feels considered
            without ever feeling complicated.
          </p>
        </div>
      </section>

      <section className="section section-muted">
        <div className="container values-grid">
          {values.map(({ icon: Icon, title, text }) => (
            <article className="value-card" key={title}>
              <Icon size={25} />
              <h3>{title}</h3>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
