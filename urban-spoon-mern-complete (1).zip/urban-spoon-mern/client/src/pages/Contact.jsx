import { Mail, MapPin, Phone, Clock3, Navigation } from 'lucide-react';
import ContactForm from '../components/forms/ContactForm';

const details = [
  { icon: MapPin, title: 'Address', text: 'Road No. 36, Jubilee Hills, Hyderabad, Telangana 500033' },
  { icon: Phone, title: 'Phone', text: '+91 98765 43210' },
  { icon: Mail, title: 'Email', text: 'hello@urbanspoon.example' },
  { icon: Clock3, title: 'Hours', text: 'Mon–Thu 12 PM–10:30 PM • Fri–Sun 12 PM–11:30 PM' }
];

export default function Contact() {
  return (
    <div className="page">
      <section className="page-hero contact-hero">
        <div className="container">
          <span className="eyebrow light">Come say hello</span>
          <h1>Contact <span>Urban Spoon.</span></h1>
          <p>Questions, celebrations, feedback or just looking for the nearest table? We are here.</p>
        </div>
      </section>

      <section className="section">
        <div className="container contact-grid">
          <div>
            <div className="detail-list">
              {details.map(({ icon: Icon, title, text }) => (
                <div className="detail-item" key={title}>
                  <div className="detail-icon"><Icon size={20} /></div>
                  <div><h3>{title}</h3><p>{text}</p></div>
                </div>
              ))}
            </div>
            <div className="map-card">
              <div className="map-placeholder">
                <Navigation size={32} />
                <strong>Jubilee Hills, Hyderabad</strong>
                <span>Map placeholder — replace with Google Maps/Mapbox in production.</span>
              </div>
            </div>
          </div>
          <div className="form-panel">
            <span className="eyebrow">Send a message</span>
            <h2>Let's talk.</h2>
            <ContactForm />
          </div>
        </div>
      </section>
    </div>
  );
}
