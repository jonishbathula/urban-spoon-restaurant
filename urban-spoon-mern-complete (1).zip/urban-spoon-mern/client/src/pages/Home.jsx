import Hero from '../components/home/Hero';
import FeatureStrip from '../components/home/FeatureStrip';
import StorySection from '../components/home/StorySection';
import FeaturedMenu from '../components/home/FeaturedMenu';
import CTASection from '../components/home/CTASection';

export default function Home() {
  return (
    <>
      <Hero />
      <FeatureStrip />
      <StorySection />
      <FeaturedMenu />
      <CTASection />
    </>
  );
}
