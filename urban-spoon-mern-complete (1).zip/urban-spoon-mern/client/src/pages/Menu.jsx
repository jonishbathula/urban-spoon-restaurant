import { useMemo, useState } from 'react';
import { categories, menuItems } from '../data/menu';
import CategoryFilter from '../components/menu/CategoryFilter';
import MenuCard from '../components/menu/MenuCard';

export default function Menu() {
  const [selected, setSelected] = useState('All');

  const visible = useMemo(
    () => selected === 'All' ? menuItems : menuItems.filter(item => item.category === selected),
    [selected]
  );

  return (
    <div className="page">
      <section className="page-hero menu-hero">
        <div className="container">
          <span className="eyebrow light">Our menu</span>
          <h1>Food with a <span>point of view.</span></h1>
          <p>Comforting classics, Indian-inspired favourites and modern plates made to share.</p>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <CategoryFilter categories={categories} selected={selected} onChange={setSelected} />
          <div className="menu-grid">
            {visible.map(item => <MenuCard key={item.id} item={item} />)}
          </div>
        </div>
      </section>
    </div>
  );
}
