import { ArrowRight, Play } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Hero() {
  return (
    <section className="hero">
      <div className="hero-image" />
      <div className="hero-overlay" />
      <div className="container hero-content">
        <span className="eyebrow light">Good food. Good mood.</span>
        <h1>Where the city comes to <span>eat, sip & stay.</span></h1>
        <p>
          A modern neighbourhood restaurant serving bold flavours, familiar comfort
          and a little bit of culinary mischief.
        </p>
        <div className="hero-actions">
          <Link to="/book" className="btn btn-primary">Book a table <ArrowRight size={18} /></Link>
          <Link to="/menu" className="btn btn-ghost"><Play size={17} /> Explore menu</Link>
        </div>
        <div className="hero-meta">
          <span>★ 4.9/5 guest rating</span>
          <span>•</span>
          <span>Freshly made daily</span>
        </div>
      </div>
    </section>
  );
}
