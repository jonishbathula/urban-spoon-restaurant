import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { menuItems } from '../../data/menu';

export default function FeaturedMenu() {
  return (
    <section className="section section-dark">
      <div className="container">
        <div className="section-heading">
          <div>
            <span className="eyebrow light">From our kitchen</span>
            <h2>Small plates. <span>Big personality.</span></h2>
          </div>
          <Link to="/menu" className="text-link light-link">See full menu <ArrowUpRight size={17} /></Link>
        </div>
        <div className="featured-grid">
          {menuItems.slice(0, 3).map((item) => (
            <article className="food-card" key={item.id}>
              <div className="food-image">
                <img src={item.image} alt={item.name} loading="lazy" />
                <span>{item.badge}</span>
              </div>
              <div className="food-info">
                <div>
                  <h3>{item.name}</h3>
                  <p>{item.description}</p>
                </div>
                <strong>₹{item.price}</strong>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
