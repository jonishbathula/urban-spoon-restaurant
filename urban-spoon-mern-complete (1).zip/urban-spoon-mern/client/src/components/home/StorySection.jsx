import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';

export default function StorySection() {
  return (
    <section className="section story-section">
      <div className="container story-grid">
        <div className="story-photo">
          <img
            src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=85"
            alt="Warmly lit restaurant interior"
          />
          <div className="photo-note">Made for conversations</div>
        </div>
        <div className="story-copy">
          <span className="eyebrow">Our table, your story</span>
          <h2>Not just dinner. A place to <span>feel at home.</span></h2>
          <p>
            Urban Spoon brings together the energy of the city and the comfort of a
            neighbourhood kitchen. Our menu moves with the seasons, but our promise
            stays the same: honest ingredients, confident cooking and generous plates.
          </p>
          <p>
            Whether it is a quick lunch, a family dinner or a late-night catch-up,
            we want every visit to become a memory worth repeating.
          </p>
          <Link to="/about" className="text-link">Discover our story <ArrowUpRight size={17} /></Link>
        </div>
      </div>
    </section>
  );
}
