import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export default function CTASection() {
  return (
    <section className="cta-section">
      <div className="container cta-inner">
        <div>
          <span className="eyebrow">Your table is waiting</span>
          <h2>Make tonight <span>delicious.</span></h2>
          <p>Pick a date, bring your people and leave the rest to us.</p>
        </div>
        <Link to="/book" className="btn btn-dark">Reserve a table <ArrowRight size={18} /></Link>
      </div>
    </section>
  );
}
