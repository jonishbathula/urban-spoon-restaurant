import { ChefHat, Leaf, HeartHandshake } from 'lucide-react';

const items = [
  { icon: ChefHat, title: 'Chef-led plates', text: 'Seasonal dishes with a modern Indian soul.' },
  { icon: Leaf, title: 'Fresh ingredients', text: 'Local produce, quality proteins and real herbs.' },
  { icon: HeartHandshake, title: 'Warm hospitality', text: 'Come hungry. Leave feeling looked after.' }
];

export default function FeatureStrip() {
  return (
    <section className="feature-strip">
      <div className="container feature-grid">
        {items.map(({ icon: Icon, title, text }) => (
          <div className="feature-item" key={title}>
            <div className="feature-icon"><Icon size={21} /></div>
            <div><h3>{title}</h3><p>{text}</p></div>
          </div>
        ))}
      </div>
    </section>
  );
}
