import { useState } from 'react';
import { sendContactMessage } from '../../services/api';
import { LoaderCircle, Send } from 'lucide-react';

export default function ContactForm() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [state, setState] = useState({ loading: false, message: '', error: false });

  function update(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function submit(e) {
    e.preventDefault();
    setState({ loading: true, message: '', error: false });
    try {
      const result = await sendContactMessage(form);
      setState({ loading: false, message: result.message, error: false });
      setForm({ name: '', email: '', message: '' });
    } catch (error) {
      setState({
        loading: false,
        message: error.response?.data?.message || 'Could not send your message.',
        error: true
      });
    }
  }

  return (
    <form className="inquiry-form" onSubmit={submit}>
      <label>Name<input name="name" value={form.name} onChange={update} required /></label>
      <label>Email<input type="email" name="email" value={form.email} onChange={update} required /></label>
      <label>Message<textarea name="message" value={form.message} onChange={update} rows="6" required maxLength="1000" /></label>
      <button className="btn btn-dark form-submit" disabled={state.loading}>
        {state.loading ? <><LoaderCircle className="spin" size={18} /> Sending...</> : <>Send message <Send size={17} /></>}
      </button>
      {state.message && <div className={`form-alert ${state.error ? 'error' : 'success'}`}>{state.message}</div>}
    </form>
  );
}
