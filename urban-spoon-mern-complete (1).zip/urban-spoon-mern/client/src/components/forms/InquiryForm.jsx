import { useMemo, useState } from 'react';
import { createInquiry } from '../../services/api';
import { CheckCircle2, LoaderCircle } from 'lucide-react';

const initialForm = {
  name: '',
  phone: '',
  email: '',
  date: '',
  time: '',
  guests: 2,
  occasion: 'Casual dining',
  message: ''
};

function getTomorrow() {
  const date = new Date();
  date.setDate(date.getDate() + 1);
  return date.toISOString().split('T')[0];
}

export default function InquiryForm() {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState({ type: '', message: '' });
  const [confirmation, setConfirmation] = useState(null);
  const [loading, setLoading] = useState(false);

  const minDate = useMemo(getTomorrow, []);

  const update = (event) => {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
    setStatus({ type: '', message: '' });
  };

  async function submit(event) {
    event.preventDefault();
    setStatus({ type: '', message: '' });

    if (form.phone && !/^[6-9]\d{9}$/.test(form.phone)) {
      setStatus({ type: 'error', message: 'Enter a valid 10-digit Indian mobile number.' });
      return;
    }

    setLoading(true);
    try {
      const result = await createInquiry({ ...form, guests: Number(form.guests) });
      setConfirmation(result.data);
      setForm(initialForm);
      setStatus({ type: 'success', message: result.message });
    } catch (error) {
      setStatus({
        type: 'error',
        message: error.response?.data?.message || 'Unable to submit your request. Please try again.'
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <form className="inquiry-form" onSubmit={submit}>
        <div className="form-row">
          <label>Full name<input name="name" value={form.name} onChange={update} required placeholder="Your name" /></label>
          <label>Phone<input name="phone" value={form.phone} onChange={update} required inputMode="numeric" maxLength="10" placeholder="9876543210" /></label>
        </div>
        <div className="form-row">
          <label>Email <span className="optional">(optional)</span><input type="email" name="email" value={form.email} onChange={update} placeholder="you@example.com" /></label>
          <label>Guests<select name="guests" value={form.guests} onChange={update}>{Array.from({ length: 20 }, (_, i) => i + 1).map(n => <option key={n} value={n}>{n} {n === 1 ? 'guest' : 'guests'}</option>)}</select></label>
        </div>
        <div className="form-row">
          <label>Date<input type="date" name="date" min={minDate} value={form.date} onChange={update} required /></label>
          <label>Preferred time<input type="time" name="time" value={form.time} onChange={update} required /></label>
        </div>
        <label>Occasion
          <select name="occasion" value={form.occasion} onChange={update}>
            <option>Casual dining</option>
            <option>Birthday</option>
            <option>Anniversary</option>
            <option>Business dinner</option>
            <option>Family gathering</option>
          </select>
        </label>
        <label>Special request <span className="optional">(optional)</span><textarea name="message" value={form.message} onChange={update} rows="4" maxLength="500" placeholder="Window seat, dietary note, celebration details..." /></label>
        <button className="btn btn-dark form-submit" disabled={loading}>
          {loading ? <><LoaderCircle className="spin" size={18} /> Sending...</> : <>Send table inquiry <CheckCircle2 size={18} /></>}
        </button>
      </form>

      {status.message && <div className={`form-alert ${status.type}`}>{status.message}</div>}

      {confirmation && (
        <div className="confirmation-card">
          <span className="success-icon"><CheckCircle2 size={23} /></span>
          <div>
            <h3>Inquiry received</h3>
            <p>We have your request for <strong>{confirmation.guests} guests</strong> on <strong>{confirmation.date}</strong> at <strong>{confirmation.time}</strong>.</p>
            <small>Reference: {confirmation.id}</small>
          </div>
        </div>
      )}
    </div>
  );
}
