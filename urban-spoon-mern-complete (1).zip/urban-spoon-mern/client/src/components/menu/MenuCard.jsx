export default function MenuCard({ item }) {
  return (
    <article className="menu-card">
      <div className="menu-card-image">
        <img src={item.image} alt={item.name} loading="lazy" />
        <span>{item.badge}</span>
      </div>
      <div className="menu-card-content">
        <div className="menu-card-title">
          <h3>{item.name}</h3>
          <strong>₹{item.price}</strong>
        </div>
        <p>{item.description}</p>
        <small>{item.category}</small>
      </div>
    </article>
  );
}
