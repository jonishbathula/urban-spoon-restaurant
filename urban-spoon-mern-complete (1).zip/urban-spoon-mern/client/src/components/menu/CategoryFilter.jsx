export default function CategoryFilter({ categories, selected, onChange }) {
  return (
    <div className="filter-row" role="tablist" aria-label="Menu categories">
      {categories.map((category) => (
        <button
          key={category}
          className={selected === category ? 'filter-btn selected' : 'filter-btn'}
          onClick={() => onChange(category)}
          role="tab"
          aria-selected={selected === category}
        >
          {category}
        </button>
      ))}
    </div>
  );
}
