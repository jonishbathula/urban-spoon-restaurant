import { Link } from 'react-router-dom';

export default function Logo() {
  return (
    <Link to="/" className="brand" aria-label="Urban Spoon home">
      <span className="brand-mark" aria-hidden="true">
        <svg viewBox="0 0 48 48">
          <path d="M13 7v13M18 7v13M23 7v13M18 20v20M33 7c-6 8-6 15 0 19v14" />
        </svg>
      </span>
      <span>
        <strong>Urban</strong>
        <em>Spoon</em>
      </span>
    </Link>
  );
}
