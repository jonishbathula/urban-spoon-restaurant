import { Link } from 'react-router-dom';
import { Clock3, MapPin, Phone, Mail, Instagram, Facebook } from 'lucide-react';
import Logo from './Logo';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <Logo />
          <p className="footer-copy">
            Modern comfort food, warm hospitality and a dining room made for slow evenings.
          </p>
          <div className="socials">
            <a href="https://www.instagram.com/" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={18} /></a>
            <a href="https://www.facebook.com/" target="_blank" rel="noreferrer" aria-label="Facebook"><Facebook size={18} /></a>
          </div>
        </div>

        <div>
          <h4>Visit us</h4>
          <p><MapPin size={16} /> Jubilee Hills, Hyderabad, Telangana</p>
          <p><Phone size={16} /> +91 98765 43210</p>
          <p><Mail size={16} /> hello@urbanspoon.example</p>
        </div>

        <div>
          <h4>Opening hours</h4>
          <p><Clock3 size={16} /> Mon–Thu: 12:00 PM – 10:30 PM</p>
          <p><Clock3 size={16} /> Fri–Sun: 12:00 PM – 11:30 PM</p>
          <Link to="/book" className="footer-link">Reserve your table →</Link>
        </div>
      </div>

      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} Urban Spoon. Internship project.</span>
        <span>Built with React + Node + MongoDB</span>
      </div>
    </footer>
  );
}
