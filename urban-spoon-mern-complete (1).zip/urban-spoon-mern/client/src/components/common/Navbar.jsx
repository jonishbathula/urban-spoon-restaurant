import { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { Menu as MenuIcon, X, CalendarDays } from 'lucide-react';
import Logo from './Logo';

const links = [
  ['/', 'Home'],
  ['/menu', 'Menu'],
  ['/about', 'About'],
  ['/contact', 'Contact']
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  const close = () => setOpen(false);

  return (
    <header className="site-header">
      <div className="container nav-wrap">
        <Logo />
        <button className="mobile-toggle" onClick={() => setOpen(!open)} aria-label="Toggle navigation">
          {open ? <X size={23} /> : <MenuIcon size={23} />}
        </button>

        <nav className={`nav-links ${open ? 'open' : ''}`}>
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} onClick={close} className={({ isActive }) => isActive ? 'active' : ''}>
              {label}
            </NavLink>
          ))}
          <Link to="/book" onClick={close} className="nav-cta">
            <CalendarDays size={17} />
            Book a table
          </Link>
        </nav>
      </div>
    </header>
  );
}
