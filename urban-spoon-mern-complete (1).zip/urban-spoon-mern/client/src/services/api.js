import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json'
  },
  timeout: 10000
});

export async function createInquiry(payload) {
  const { data } = await api.post('/inquiries', payload);
  return data;
}

export async function getInquiries() {
  const { data } = await api.get('/inquiries');
  return data;
}

export async function deleteInquiry(id) {
  const { data } = await api.delete(`/inquiries/${id}`);
  return data;
}

export async function sendContactMessage(payload) {
  const { data } = await api.post('/contact', payload);
  return data;
}
